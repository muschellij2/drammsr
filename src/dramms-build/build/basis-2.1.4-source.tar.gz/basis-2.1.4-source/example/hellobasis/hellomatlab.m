% @file  hellomatlab.m
% @brief The not so typical Hello World! example program.
%
% Copyright (c) 2011 University of Pennsylvania. All rights reserved.<br />
% See http://www.rad.upenn.edu/sbia/software/license.html or COPYING file.
%
% Contact: SBIA Group <sbia-software at uphs.upenn.edu>

disp('How is it going?')
