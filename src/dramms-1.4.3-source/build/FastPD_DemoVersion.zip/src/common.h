#ifndef _COMMON_H_
#define _COMMON_H_

typedef short TIME;

#endif
